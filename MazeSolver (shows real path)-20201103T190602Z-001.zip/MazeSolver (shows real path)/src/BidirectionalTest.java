

// Filename: BidirectionalTest.java
// Description: Test file for Bidirectional

import javax.swing.JFrame;

public class BidirectionalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame = new Bidirectional();
		frame.setTitle("Search & Rescue");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);


	}
}